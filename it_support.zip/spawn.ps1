# ============================================================ 
# Phase1-Populate-Dummies.ps1 
# [SIMULATION] Create dummy files for ransomware exercise 
# ============================================================ 
#
# .\spawn.ps1 -TargetUser "[USER]"

param(
    [string]$TargetUser
)

Write-Host "=====================================================" -ForegroundColor Cyan 
Write-Host "[SIMULATION] Phase 1 - Dummy File Creation" -ForegroundColor Cyan 
Write-Host "=====================================================" -ForegroundColor Cyan
if ($TargetUser) {
    Write-Host "[TARGET] - $TargetUser" -ForegroundColor Red
    $rootDir = "c:\users\$TargetUser"
    $dirs = @("$rootDir\Downloads","$rootDir\Documents","c:\users\$TargetUser\Desktop")
    $manifestDir = "$rootDir\Manifests"
    New-Item -Path $manifestDir -ItemType Directory -Force | Out-Null 
}
else {
    # Create directory structure
    $rootDir = "c:\temp"
    $dirs = @( "$rootDir\Data", "$rootDir\Logs", "$rootDir\Manifests", "$rootDir\Evidence" ) 
    foreach ($d in $dirs) { 
        New-Item -Path $d -ItemType Directory -Force | Out-Null 
        Write-Host "[+] Created directory: $d" -ForegroundColor Green 
    }
}

$startTime = Get-Date

<#
# Register Event Log source (required before writing events) 
try { New-EventLog -LogName Application -Source "RansomSim" -ErrorAction Stop 
Write-Host "[+] Registered Event Log source: RansomSim" -ForegroundColor Green 
} 
catch { 
    Write-Host "[i] Event Log source 'RansomSim' already exists." -ForegroundColor Yellow 
}
#>
$manifest = @() 
$fileCount = 0

if ($TargetUser) {
	$documentsDir = Join-Path $rootDir -ChildPath "Documents"
    $desktopDir = Join-Path $rootDir -ChildPath "Desktop"
    $downloadDir = Join-Path $rootDir -ChildPath "Downloads"
    # --- DOCX-format text files (5) --- 
    $docxContent = @( "Q3 Revenue Analysis`r`nPrepared by Finance Department`r`nTotal revenue increased 12% YoY driven by enterprise segment growth.", "[SIMULATION TEST DATA - NOT REAL]`r`nProject Charter: Cloud Migration`r`nSponsor: CTO Office`r`nObjective: Migrate 80% of on-premise workloads to Azure by Q4.", "[SIMULATION TEST DATA - NOT REAL]`r`nEmployee Onboarding Guide`r`nHuman Resources Division`r`nThis document outlines the standard 90-day onboarding process.", "[SIMULATION TEST DATA - NOT REAL]`r`nVendor Risk Assessment Report`r`nThird-Party Risk Management`r`nAll Tier-1 vendors have been assessed against the NIST CSF framework.", "[SIMULATION TEST DATA - NOT REAL]`r`nBoard Meeting Minutes - March 2026`r`nAttendees: Board of Directors`r`nMotion to approve the FY2027 budget was carried unanimously." ) 
    for ($i = 1; $i -le 5; $i++) { 
        #$path = "C:\RansomSim\TestData\document_$i.docx"
        $doc_path = "$documentsDir\document_$i.docx"
        Set-Content -Path $doc_path -Value $docxContent[$i - 1] -Encoding UTF8
        $fileCount++ 
    }
    # --- XLSX-format text files (5) --- 
    $xlsxContent = @( "Date,Department,Amount,Category`r`n2026-01-15,Engineering,45000,Salaries`r`n2026-01-15,Marketing,12000,Advertising`r`n2026-01-15,Sales,28000,Commissions", "[SIMULATION TEST DATA - NOT REAL]`r`nServer,CPU%,Memory%,Disk%,Status`r`nWEB-01,42,68,55,Healthy`r`nWEB-02,38,72,61,Healthy`r`nDB-01,87,91,78,Warning", "[SIMULATION TEST DATA - NOT REAL]`r`nEmployee,Title,Department,StartDate`r`nJSmith,Sr Engineer,Engineering,2022-03-15`r`nAJones,Analyst,Finance,2023-07-01", "[SIMULATION TEST DATA - NOT REAL]`r`nTicket,Priority,Status,Assignee,SLA`r`nINC-001,High,Open,TeamA,4hrs`r`nINC-002,Medium,In Progress,TeamB,8hrs", "[SIMULATION TEST DATA - NOT REAL]`r`nQuarter,Revenue,Expenses,Profit,Margin`r`nQ1-2026,2400000,1800000,600000,25%`r`nQ2-2026,2650000,1950000,700000,26.4%" )
    for ($i = 1; $i -le 5; $i++) { 
        $sheet_path = "$documentsDir\spreadsheet_$i.xlsx" 
        Set-Content -Path $sheet_path -Value $xlsxContent[$i - 1] -Encoding UTF8 
        $fileCount++ 
    }
    # --- PDF-format text files (5) --- 
    $pdfContent = @( "Information Security Policy v4.2`r`nEffective Date: January 2026`r`nAll employees must complete annual security awareness training.", "[SIMULATION TEST DATA - NOT REAL]`r`nIncident Response Plan`r`nClassification: Internal`r`nThis plan defines the procedures for detecting and responding to security incidents.", "[SIMULATION TEST DATA - NOT REAL]`r`nBusiness Continuity Plan`r`nRTO: 4 hours | RPO: 1 hour`r`nCritical systems must be recoverable within the defined RTO.", "[SIMULATION TEST DATA - NOT REAL]`r`nPenetration Test Report - External`r`nTesting Period: February 2026`r`nNo critical vulnerabilities were identified during the assessment.", "[SIMULATION TEST DATA - NOT REAL]`r`nCompliance Audit Report - SOC 2 Type II`r`nAudit Period: Jan-Dec 2025`r`nAll trust service criteria were met without exception." ) 
    for ($i = 1; $i -le 5; $i++) { 
        $pdf_path = "$desktopDir\report_$i.pdf"
        Set-Content -Path $pdf_path -Value $pdfContent[$i - 1] -Encoding UTF8
        $fileCount++ 
    }
    # --- JPG files (5, 50KB random bytes each) --- 
    for ($i = 1; $i -le 5; $i++) { 
        $img_path = "$desktopDir\image_$i.jpg"
        #Create byte buffer
        $bytes = New-Object byte[] 51200
        #Fill with random data
        $rng = (New-Object Random).NextBytes($bytes) 
        # Stamp simulation marker in first bytes 
        $marker = [System.Text.Encoding]::ASCII.GetBytes("[SIMULATION]")
        [Array]::Copy($marker, $bytes, $marker.Length) 
        [System.IO.File]::WriteAllBytes($img_path, $bytes)
        $fileCount++ 
    }
    # --- TXT files (5) --- 

    $txtContent = @( "[SIMULATION TEST DATA - NOT REAL]`r`nMeeting Notes - Weekly Standup`r`nDate: 2026-04-10`r`nAttendees: Dev Team Alpha`r`nAction Items:`r`n- Complete API integration by Friday`r`n- Review pull request #487`r`n- Schedule load test for staging environment", "[SIMULATION TEST DATA - NOT REAL]`r`nProject Plan: Zero Trust Implementation`r`nPhase 1: Identity (Q1-Q2)`r`nPhase 2: Network segmentation (Q3)`r`nPhase 3: Endpoint validation (Q4)`r`nBudget: $450,000 approved", "[SIMULATION TEST DATA - NOT REAL]`r`nChange Advisory Board Notes`r`nCHG-2026-0142: Database upgrade approved`r`nCHG-2026-0143: Firewall rule change deferred`r`nNext CAB meeting: 2026-04-24", "[SIMULATION TEST DATA - NOT REAL]`r`nKnowledge Base Article: VPN Troubleshooting`r`nStep 1: Verify network connectivity`r`nStep 2: Check VPN client version`r`nStep 3: Clear DNS cache and retry", "[SIMULATION TEST DATA - NOT REAL]`r`nPost-Incident Review: INC-2026-0089`r`nRoot Cause: Expired TLS certificate on load balancer`r`nImpact: 22 minutes of downtime for customer portal`r`nRemediation: Implemented automated certificate renewal" ) 
    for ($i = 1; $i -le 5; $i++) { 
        $txt_path = "$downloadDir\notes_$i.txt" 
        Set-Content -Path $txt_path -Value $txtContent[$i - 1] -Encoding UTF8
        $fileCount++
    }
    $files = Get-ChildItem -Path "$documentsDir" -File
}
else {
	$documentsDir = "$rootDir\Data\Documents"
    # --- DOCX-format text files (5) --- 
    $docxContent = @( "Q3 Revenue Analysis`r`nPrepared by Finance Department`r`nTotal revenue increased 12% YoY driven by enterprise segment growth.", "[SIMULATION TEST DATA - NOT REAL]`r`nProject Charter: Cloud Migration`r`nSponsor: CTO Office`r`nObjective: Migrate 80% of on-premise workloads to Azure by Q4.", "[SIMULATION TEST DATA - NOT REAL]`r`nEmployee Onboarding Guide`r`nHuman Resources Division`r`nThis document outlines the standard 90-day onboarding process.", "[SIMULATION TEST DATA - NOT REAL]`r`nVendor Risk Assessment Report`r`nThird-Party Risk Management`r`nAll Tier-1 vendors have been assessed against the NIST CSF framework.", "[SIMULATION TEST DATA - NOT REAL]`r`nBoard Meeting Minutes - March 2026`r`nAttendees: Board of Directors`r`nMotion to approve the FY2027 budget was carried unanimously." ) 
    for ($i = 1; $i -le 5; $i++) { 
        #$path = "C:\RansomSim\TestData\document_$i.docx"
        $doc_path = "$documentsDir\document_$i.docx"
        Set-Content -Path $doc_path -Value $docxContent[$i - 1] -Encoding UTF8
        $fileCount++ 
    }
    # --- XLSX-format text files (5) --- 
    $xlsxContent = @( "Date,Department,Amount,Category`r`n2026-01-15,Engineering,45000,Salaries`r`n2026-01-15,Marketing,12000,Advertising`r`n2026-01-15,Sales,28000,Commissions", "[SIMULATION TEST DATA - NOT REAL]`r`nServer,CPU%,Memory%,Disk%,Status`r`nWEB-01,42,68,55,Healthy`r`nWEB-02,38,72,61,Healthy`r`nDB-01,87,91,78,Warning", "[SIMULATION TEST DATA - NOT REAL]`r`nEmployee,Title,Department,StartDate`r`nJSmith,Sr Engineer,Engineering,2022-03-15`r`nAJones,Analyst,Finance,2023-07-01", "[SIMULATION TEST DATA - NOT REAL]`r`nTicket,Priority,Status,Assignee,SLA`r`nINC-001,High,Open,TeamA,4hrs`r`nINC-002,Medium,In Progress,TeamB,8hrs", "[SIMULATION TEST DATA - NOT REAL]`r`nQuarter,Revenue,Expenses,Profit,Margin`r`nQ1-2026,2400000,1800000,600000,25%`r`nQ2-2026,2650000,1950000,700000,26.4%" )
    for ($i = 1; $i -le 5; $i++) { 
        $sheet_path = "$documentsDir\spreadsheet_$i.xlsx" 
        Set-Content -Path $sheet_path -Value $xlsxContent[$i - 1] -Encoding UTF8 
        $fileCount++ 
    }
    # --- PDF-format text files (5) --- 
    $pdfContent = @( "Information Security Policy v4.2`r`nEffective Date: January 2026`r`nAll employees must complete annual security awareness training.", "[SIMULATION TEST DATA - NOT REAL]`r`nIncident Response Plan`r`nClassification: Internal`r`nThis plan defines the procedures for detecting and responding to security incidents.", "[SIMULATION TEST DATA - NOT REAL]`r`nBusiness Continuity Plan`r`nRTO: 4 hours | RPO: 1 hour`r`nCritical systems must be recoverable within the defined RTO.", "[SIMULATION TEST DATA - NOT REAL]`r`nPenetration Test Report - External`r`nTesting Period: February 2026`r`nNo critical vulnerabilities were identified during the assessment.", "[SIMULATION TEST DATA - NOT REAL]`r`nCompliance Audit Report - SOC 2 Type II`r`nAudit Period: Jan-Dec 2025`r`nAll trust service criteria were met without exception." ) 
    for ($i = 1; $i -le 5; $i++) { 
        $pdf_path = "$documentsDir\report_$i.pdf"
        Set-Content -Path $pdf_path -Value $pdfContent[$i - 1] -Encoding UTF8
        $fileCount++ 
    }
    # --- JPG files (5, 50KB random bytes each) --- 
    for ($i = 1; $i -le 5; $i++) { 
        $img_path = "$documentsDir\image_$i.jpg"
        #Create byte buffer
        $bytes = New-Object byte[] 51200
        #Fill with random data
        $rng = (New-Object Random).NextBytes($bytes) 
        # Stamp simulation marker in first bytes 
        $marker = [System.Text.Encoding]::ASCII.GetBytes("[SIMULATION]")
        [Array]::Copy($marker, $bytes, $marker.Length) 
        [System.IO.File]::WriteAllBytes($img_path, $bytes)
        $fileCount++ 
    }
    # --- TXT files (5) --- 
    $txtContent = @( "[SIMULATION TEST DATA - NOT REAL]`r`nMeeting Notes - Weekly Standup`r`nDate: 2026-04-10`r`nAttendees: Dev Team Alpha`r`nAction Items:`r`n- Complete API integration by Friday`r`n- Review pull request #487`r`n- Schedule load test for staging environment", "[SIMULATION TEST DATA - NOT REAL]`r`nProject Plan: Zero Trust Implementation`r`nPhase 1: Identity (Q1-Q2)`r`nPhase 2: Network segmentation (Q3)`r`nPhase 3: Endpoint validation (Q4)`r`nBudget: $450,000 approved", "[SIMULATION TEST DATA - NOT REAL]`r`nChange Advisory Board Notes`r`nCHG-2026-0142: Database upgrade approved`r`nCHG-2026-0143: Firewall rule change deferred`r`nNext CAB meeting: 2026-04-24", "[SIMULATION TEST DATA - NOT REAL]`r`nKnowledge Base Article: VPN Troubleshooting`r`nStep 1: Verify network connectivity`r`nStep 2: Check VPN client version`r`nStep 3: Clear DNS cache and retry", "[SIMULATION TEST DATA - NOT REAL]`r`nPost-Incident Review: INC-2026-0089`r`nRoot Cause: Expired TLS certificate on load balancer`r`nImpact: 22 minutes of downtime for customer portal`r`nRemediation: Implemented automated certificate renewal" ) 
    for ($i = 1; $i -le 5; $i++) { 
        $txt_path = "$documentsDir\notes_$i.txt" 
        Set-Content -Path $txt_path -Value $txtContent[$i - 1] -Encoding UTF8
        $fileCount++
    }
    $files = Get-ChildItem -Path "$documentsDir" -File
}



# Generate manifest Write-Host "`n[*] Computing file hashes and building manifest..." -ForegroundColor Yellow

 
foreach ($file in $files) { 
    $hash = (Get-FileHash -Path $file.FullName -Algorithm SHA256).Hash 
    $manifest += [PSCustomObject]@{ FileName = $file.Name; FilePath = $file.FullName; SizeBytes= $file.Length; SHA256Hash = $hash; CreatedUTC = $file.CreationTimeUtc.ToString("yyyy-MM-ddTHH:mm:ssZ") 
} 
}

$manifestPath = "$manifestDir\pre-transform-manifest.csv" 
$manifest | Export-Csv -Path $manifestPath -NoTypeInformation -Encoding UTF8
$totalSize = ($manifest | Measure-Object -Property SizeBytes -Sum).Sum
Write-Host "" 
Write-Host "=====================================================" -ForegroundColor Green 
Write-Host "[Populate] Phase 1 Complete" -ForegroundColor Green
Write-Host "=====================================================" -ForegroundColor Green
Write-Host "Total files created : $fileCount" 
Write-Host "Total size: $([math]::Round($totalSize / 1KB, 2)) KB" 
Write-Host "Manifest path : $manifestPath" 
Write-Host "Elapsed time: $((Get-Date) - $startTime)" 
